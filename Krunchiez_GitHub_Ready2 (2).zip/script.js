
const cart = JSON.parse(localStorage.getItem("krunchiezCart") || "[]");
const cartPanel = document.getElementById("cartPanel");
const overlay = document.getElementById("overlay");
const cartItems = document.getElementById("cartItems");
const cartCount = document.getElementById("cartCount");
const cartTotal = document.getElementById("cartTotal");
const toast = document.getElementById("toast");

function save(){ localStorage.setItem("krunchiezCart", JSON.stringify(cart)); render(); }
function money(n){ return "₹" + n; }

function render(){
  cartItems.innerHTML = "";
  let total = 0, count = 0;
  if(!cart.length){
    cartItems.innerHTML = '<p class="empty">Your cart is waiting for a crunch.</p>';
  } else {
    cart.forEach((item,i)=>{
      total += item.price * item.qty;
      count += item.qty;
      const row = document.createElement("div");
      row.className = "cart-row";
      row.innerHTML = `
        <div><h4>${item.name}</h4><small>${item.weight} • ${money(item.price)} each</small></div>
        <div class="qty"><button data-i="${i}" data-d="-1">−</button><b>${item.qty}</b><button data-i="${i}" data-d="1">+</button></div>
      `;
      cartItems.appendChild(row);
    });
  }
  cartCount.textContent = count;
  cartTotal.textContent = money(total);
}
function showToast(){
  toast.classList.add("show");
  setTimeout(()=>toast.classList.remove("show"),1300);
}
document.querySelectorAll(".add-btn").forEach(btn=>{
  btn.addEventListener("click",()=>{
    const data = {name:btn.dataset.name, price:Number(btn.dataset.price), weight:btn.dataset.weight, qty:1};
    const found = cart.find(x=>x.name===data.name);
    if(found) found.qty++;
    else cart.push(data);
    save(); showToast();
  });
});
cartItems.addEventListener("click",(e)=>{
  const b=e.target.closest("button[data-i]");
  if(!b)return;
  const i=Number(b.dataset.i), d=Number(b.dataset.d);
  cart[i].qty += d;
  if(cart[i].qty<=0) cart.splice(i,1);
  save();
});
function openCart(){cartPanel.classList.add("open");overlay.classList.add("show")}
function closeCart(){cartPanel.classList.remove("open");overlay.classList.remove("show")}
document.getElementById("openCart").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
overlay.onclick=closeCart;
document.getElementById("checkoutBtn").onclick=()=>{
  if(!cart.length){ alert("Your cart is empty."); return; }
  alert("Checkout UI is ready. Next step: connect your payment gateway and delivery partner.");
};
render();

