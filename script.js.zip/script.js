/* Krunchiez Website - script.js */

document.addEventListener("DOMContentLoaded", () => {
  const cart = JSON.parse(localStorage.getItem("krunchiezCart") || "[]");

  const products = {
    "Peri Peri": { price: 32 },
    "Madness Masala": { price: 32 },
    "Caramel": { price: 42 }
  };

  function saveCart() {
    localStorage.setItem("krunchiezCart", JSON.stringify(cart));
  }

  function updateCartCount() {
    const count = cart.reduce((total, item) => total + item.quantity, 0);
    document.querySelectorAll("[data-cart-count]").forEach(el => {
      el.textContent = count;
    });
  }

  function addToCart(name) {
    if (!products[name]) return;

    const existing = cart.find(item => item.name === name);

    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({
        name,
        price: products[name].price,
        quantity: 1
      });
    }

    saveCart();
    updateCartCount();
    alert(`${name} added to cart!`);
  }

  document.querySelectorAll("[data-add-to-cart]").forEach(button => {
    button.addEventListener("click", () => {
      addToCart(button.dataset.addToCart);
    });
  });

  updateCartCount();

  // Smooth scrolling for navigation links
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", event => {
      const targetId = link.getAttribute("href");
      const target = document.querySelector(targetId);

      if (target) {
        event.preventDefault();
        target.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });
      }
    });
  });

  // Simple cart drawer/page support if the HTML contains these elements
  const cartButton = document.querySelector("[data-cart-button]");
  const cartPanel = document.querySelector("[data-cart-panel]");
  const cartClose = document.querySelector("[data-cart-close]");

  if (cartButton && cartPanel) {
    cartButton.addEventListener("click", () => {
      cartPanel.classList.add("open");
      renderCart();
    });
  }

  if (cartClose && cartPanel) {
    cartClose.addEventListener("click", () => {
      cartPanel.classList.remove("open");
    });
  }

  function renderCart() {
    const container = document.querySelector("[data-cart-items]");
    const totalElement = document.querySelector("[data-cart-total]");

    if (!container) return;

    container.innerHTML = "";

    if (cart.length === 0) {
      container.innerHTML = "<p>Your cart is empty.</p>";
      if (totalElement) totalElement.textContent = "₹0";
      return;
    }

    let total = 0;

    cart.forEach((item, index) => {
      const itemTotal = item.price * item.quantity;
      total += itemTotal;

      const row = document.createElement("div");
      row.className = "cart-item";
      row.innerHTML = `
        <div>
          <strong>${item.name}</strong>
          <span>₹${item.price} × ${item.quantity}</span>
        </div>
        <button type="button" data-remove-index="${index}">Remove</button>
      `;

      container.appendChild(row);
    });

    if (totalElement) {
      totalElement.textContent = `₹${total}`;
    }

    container.querySelectorAll("[data-remove-index]").forEach(button => {
      button.addEventListener("click", () => {
        cart.splice(Number(button.dataset.removeIndex), 1);
        saveCart();
        updateCartCount();
        renderCart();
      });
    });
  }
});
